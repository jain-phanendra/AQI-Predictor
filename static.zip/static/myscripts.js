const stateCityLocation = {
    "Maharashtra": {
        "Mumbai": ["Andheri", "Borivali"],
        "Pune": ["Karve Road"]
    },
    "Delhi": {
        "Delhi": ["ITO", "Rohini"]
    },
    "Uttar Pradesh": {
        "Moradabad": ["Herbal Park", "Buddhi Vihar"],
        "Lucknow": ["Talkatora District Industries Center", "Lalbagh"],
        "Ghaziabad": ["Sanjay Nagar", "Loni"],
        "Greater Noida": ["Knowledge Park-III", "Knowledge Park-V"],
        "Agra": ["Shahjahan Garden"]
    }
};

const stateSelect = document.getElementById("state");
const citySelect = document.getElementById("city");
const locationSelect = document.getElementById("location");

stateSelect.addEventListener("change", () => {
    const cities = stateCityLocation[stateSelect.value];
    citySelect.innerHTML = `<option value="">Select City</option>`;
    locationSelect.innerHTML = `<option value="">Select Location</option>`;
    if (cities) {
        Object.keys(cities).forEach(city => {
            citySelect.innerHTML += `<option value="${city}">${city}</option>`;
        });
    }
});

citySelect.addEventListener("change", () => {
    const locations = stateCityLocation[stateSelect.value]?.[citySelect.value];
    locationSelect.innerHTML = `<option value="">Select Location</option>`;
    if (locations) {
        locations.forEach(loc => {
            locationSelect.innerHTML += `<option value="${loc}">${loc}</option>`;
        });
    }
});

document.getElementById("aqiForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const location = locationSelect.value;
    const date = document.getElementById("date").value;

    if (!location || !date) return;

    fetch("/predict", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ location, date })
    })
    .then(res => res.json())
    .then(data => {
        const result = document.getElementById("predictionResult");
        const graph = document.getElementById("graphContainer");

        if (data.status === "success") {
            const predictedAQI = (data.predicted_aqi !== null && data.predicted_aqi !== undefined)
                ? data.predicted_aqi
                : "N/A";
            const aqiCategory = data.aqi_category || "N/A";
            const aqiPrecaution = data.aqi_precaution || "N/A";

            result.innerHTML = `
                <h3>AQI Forecast for ${data.selected_date}</h3>
                <p><strong>Predicted AQI:</strong> ${predictedAQI}</p>
                <p><strong>Category:</strong> ${aqiCategory}</p>
                <p><strong>Precaution:</strong> ${aqiPrecaution}</p>
                <p><small>Graph shows AQI from ${data.start_date} to ${data.end_date}</small></p>
            `;

            const timestamp = new Date().getTime();
            graph.innerHTML = `<img src="${data.graph_url}?t=${timestamp}" alt="AQI Forecast Graph" >`;
        } else {
            result.innerHTML = `<p style="color:red;">${data.message}</p>`;
            graph.innerHTML = "";
        }
    })
    .catch(err => {
        console.error("Prediction error:", err);
    });
});
